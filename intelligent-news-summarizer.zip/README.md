# Intelligent News Summarizer

This is a ready-to-run project for an Intelligent News Summarizer with Sentiment Analysis.

**Important:** This ZIP *does not* include the large pretrained model weights (they are not available in this environment).
A `models/` folder and a `download_models.sh` script are included to help you download those models locally.

## What's inside
- `backend/` - FastAPI backend that ingests articles and runs summarization + sentiment.
- `frontend/` - Minimal React frontend (Vite).
- `docker-compose.yml` - Combined compose for backend, frontend, and Postgres.
- `models/` - Placeholder directory for model files.
- `download_models.sh` - Script to download recommended Hugging Face models (run locally).
- `sample_data/` - Contains one sample article for immediate testing.

## How to run (after downloading models)
1. Ensure Docker Desktop is installed.
2. Place model files into `models/` (see `download_models.sh`) or run `./download_models.sh` locally.
3. From project root run:
   ```
   docker compose up --build
   ```
4. Open http://localhost:5173 and test.

If you need help uploading this to GitHub or running the model download script locally, tell me and I'll provide exact commands.
