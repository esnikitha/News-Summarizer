import React, {useState} from 'react'
import axios from 'axios'

function App(){
  const [url, setUrl] = useState('')
  const [article, setArticle] = useState(null)
  const [analysis, setAnalysis] = useState(null)

  async function handleIngest(){
    try{
      const res = await axios.post('http://localhost:8000/ingest', { url })
      setArticle(res.data)
    }catch(e){
      alert('Ingest failed: ' + (e?.response?.data || e.message))
    }
  }

  async function handleAnalyze(){
    if(!article) return
    const res = await axios.post(`http://localhost:8000/analyze/${article.id}`)
    setAnalysis(res.data)
  }

  return (
    <div style={{padding:20}}>
      <h1>News Summarizer — Demo</h1>
      <div>
        <input placeholder="Article URL" value={url} onChange={e=>setUrl(e.target.value)} style={{width:600}} />
        <button onClick={handleIngest}>Ingest</button>
        <button onClick={handleAnalyze} disabled={!article}>Analyze</button>
      </div>

      {article && (
        <div style={{marginTop:20, padding:20, border:'1px solid #ddd', borderRadius:8}}>
          <h2>{article.title || 'Untitled'}</h2>
          <a href={article.url} target="_blank" rel="noreferrer">Open original</a>
          <p>{article.text ? article.text.slice(0,400) + '...' : 'No text stored'}</p>
          {analysis && (
            <div>
              <h3>Summary</h3>
              <p>{analysis.summary}</p>
              <h3>Sentiment</h3>
              <p>{analysis.sentiment.label} ({analysis.sentiment.score})</p>
            </div>
          )}
        </div>
      )}
    </div>
  )
}

export default App
