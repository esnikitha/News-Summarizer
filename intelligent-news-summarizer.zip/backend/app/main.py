from fastapi import FastAPI, Depends, HTTPException
from .db import get_db, Base, engine
from .models import Article, ArticleIn, ArticleOut
from .ingest import ingest_article_sync
from .pipeline import make_embedding, summarize_text, analyze_sentiment
import os

# create DB tables
Base.metadata.create_all(bind=engine)

app = FastAPI(title="News Summarizer API")

@app.post('/ingest', response_model=ArticleOut)
def ingest_endpoint(payload: ArticleIn, db=Depends(get_db)):
    art = ingest_article_sync(db, payload.url)
    if not art:
        raise HTTPException(500, "Failed to ingest")
    return art

@app.get('/articles/{article_id}', response_model=ArticleOut)
def get_article(article_id: int, db=Depends(get_db)):
    art = db.query(Article).filter(Article.id == article_id).first()
    if not art:
        raise HTTPException(404, 'Not found')
    return art

@app.post('/analyze/{article_id}')
def analyze_article(article_id: int, db=Depends(get_db)):
    art = db.query(Article).filter(Article.id == article_id).first()
    if not art:
        raise HTTPException(404, 'Not found')
    emb = make_embedding(art.text)
    summary = summarize_text(art.text)
    sentiment = analyze_sentiment(art.text)
    emb_list = emb.tolist() if emb is not None else None
    return {
        'article_id': art.id,
        'summary': summary,
        'sentiment': sentiment,
        'embedding_dim': len(emb_list) if emb_list else 0
    }
