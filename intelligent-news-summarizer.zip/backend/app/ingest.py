from .utils import parse_article_with_newspaper, parse_date
from .models import Article
from sqlalchemy.exc import IntegrityError

def ingest_article_sync(db, url, source=None):
    parsed = parse_article_with_newspaper(url)
    art = Article(
        url=url,
        title=parsed.get('title'),
        text=parsed.get('text'),
        published_at=parse_date(parsed.get('published_at')),
        source=source
    )
    try:
        db.add(art)
        db.commit()
        db.refresh(art)
        return art
    except IntegrityError:
        db.rollback()
        existing = db.query(Article).filter(Article.url == url).first()
        return existing
