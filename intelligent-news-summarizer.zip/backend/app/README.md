Backend notes:
- Place model folders inside /models (mapped into container at /app/models) or run the included download_models.sh locally.
- To run without Docker: create a virtualenv, pip install -r requirements.txt, then run `uvicorn app.main:app --reload`
