from sqlalchemy import Column, Integer, String, Text, DateTime
from sqlalchemy.sql import func
from .db import Base

class Article(Base):
    __tablename__ = "articles"
    id = Column(Integer, primary_key=True, index=True)
    url = Column(String, unique=True, index=True, nullable=False)
    title = Column(String, nullable=True)
    text = Column(Text, nullable=True)
    published_at = Column(DateTime, nullable=True)
    source = Column(String, nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

# Pydantic models
from pydantic import BaseModel
from typing import Optional
from datetime import datetime

class ArticleIn(BaseModel):
    url: str

class ArticleOut(BaseModel):
    id: int
    url: str
    title: Optional[str]
    text: Optional[str]
    published_at: Optional[datetime]
    source: Optional[str]

    class Config:
        orm_mode = True
