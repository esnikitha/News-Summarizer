from newspaper import Article
from dateutil import parser as dateparser

def parse_article_with_newspaper(url):
    art = Article(url)
    art.download()
    art.parse()
    return {
        "title": art.title,
        "text": art.text,
        "authors": art.authors,
        "published_at": art.publish_date,
        "top_image": art.top_image,
    }

def parse_date(d):
    if not d:
        return None
    if isinstance(d, str):
        try:
            return dateparser.parse(d)
        except Exception:
            return None
    return d
