from sentence_transformers import SentenceTransformer
from transformers import pipeline
import os

# Models directory (container will mount project /models to /app/models)
MODELS_DIR = os.getenv("MODELS_DIR", "/app/models")

# Recommended model names (Hugging Face) - these will be downloaded into MODELS_DIR by download_models.sh
EMBED_MODEL_PATH = os.path.join(MODELS_DIR, "all-MiniLM-L6-v2")
SUMMARIZER_MODEL_PATH = os.path.join(MODELS_DIR, "facebook-bart-large-cnn")
SENTIMENT_MODEL_PATH = os.path.join(MODELS_DIR, "cardiffnlp-twitter-roberta-base-sentiment")

# Load models if available, otherwise fall back to small local initializers
def safe_load_sentence_transformer(path):
    try:
        return SentenceTransformer(path)
    except Exception as e:
        print(f'Could not load embedding model from {path}:', e)
        return SentenceTransformer('all-MiniLM-L6-v2')

def safe_load_summarizer(path):
    try:
        return pipeline('summarization', model=path)
    except Exception as e:
        print(f'Could not load summarizer from {path}:', e)
        return pipeline('summarization', model='facebook/bart-large-cnn')

def safe_load_sentiment(path):
    try:
        return pipeline('sentiment-analysis', model=path)
    except Exception as e:
        print(f'Could not load sentiment model from {path}:', e)
        return pipeline('sentiment-analysis', model='cardiffnlp/twitter-roberta-base-sentiment')

EMBED_MODEL = safe_load_sentence_transformer(EMBED_MODEL_PATH)
SUMMARIZER = safe_load_summarizer(SUMMARIZER_MODEL_PATH)
SENTIMENT = safe_load_sentiment(SENTIMENT_MODEL_PATH)

def make_embedding(text: str):
    if not text:
        return None
    excerpt = text if len(text) < 2000 else text[:2000]
    emb = EMBED_MODEL.encode(excerpt, convert_to_numpy=True)
    return emb

def summarize_text(text: str, min_length=30, max_length=120):
    if not text:
        return ""
    if len(text) > 3000:
        text = text[:3000]
    res = SUMMARIZER(text, max_length=max_length, min_length=min_length, do_sample=False)
    return res[0]["summary_text"]

def analyze_sentiment(text: str):
    if not text:
        return {"label": "neutral", "score": 0.5}
    sample = text[:512]
    res = SENTIMENT(sample)
    label = res[0]["label"]
    score = float(res[0]["score"])
    if label.lower().startswith("label_"):
        mapping = {"LABEL_0": "negative", "LABEL_1": "neutral", "LABEL_2": "positive"}
        mapped = mapping.get(label, "neutral")
    else:
        mapped = label.lower()
    return {"label": mapped, "score": score}
